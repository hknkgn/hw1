#ifndef GTUVECTOR_H_
#define GTUVECTOR_H_

#include "GTUContainer.h"

namespace GTUSTL
{
	template<class T>
	class GTUVector : public GTUContainer<T>
	{
		public:
			GTUVector();
			GTUVector(const GTUVector& rightSide);
			GTUVector& operator =(const GTUVector& rightSide);
			bool empty() const;
			int size() const;
			int max_size() const;
			void insert(const T& Object);
			void erase(const GTUIterator<T>& erasing_iter);
			void erase(const GTUIterator<T>& start_iterator, const GTUIterator<T>& finish_iterator);
			void clear();
			T operator [](const int& index) const;
			void printVector() const;
			GTUIterator<T> begin() const;
			GTUIterator<T> end() const;
			static void print_element(T element);
			static bool isNegative(T element);
	};
}

#endif