#include "GTUIteratorConst.h"

namespace GTUSTL
{
	template<class T>
	GTUIteratorConst<T>::GTUIteratorConst(T* traverser)
					: traverser(traverser)
	{
				
	}

	template<class T>
	GTUIteratorConst<T>::GTUIteratorConst()
					: traverser(nullptr)
	{

	}

	template<class T>
	GTUIteratorConst<T>& GTUIteratorConst<T>::operator =(const GTUIteratorConst& rightSide) 
	{
		this -> traverser = rightSide.traverser;

		return (*this);
	}

	template<class T>
	const T& GTUIteratorConst<T>::operator * () const 
	{
		return *traverser;
	}

	template<class T>
	const T* GTUIteratorConst<T>::operator -> () const 
	{
		return traverser;
	}

	template<class T>
	GTUIteratorConst<T>& GTUIteratorConst<T>::operator ++() 
	{
		traverser++;

		return (*this);
	}

	template<class T>
	GTUIteratorConst<T>& GTUIteratorConst<T>::operator ++(int ignored) 
	{
		GTUIteratorConst temp = (*this);
		traverser++;

		return temp;
	}

	template<class T>
	GTUIteratorConst<T>& GTUIteratorConst<T>::operator --() 
	{
		traverser--;

		return (*this);
	}

	template<class T>
	GTUIteratorConst<T>& GTUIteratorConst<T>::operator --(int ignored) 
	{
		GTUIteratorConst temp = (*this);
		traverser--;

		return temp;
	}

	template<class T>
	bool GTUIteratorConst<T>::operator ==(const GTUIteratorConst& rightSide) const 
	{
		return (this -> traverser == rightSide.traverser);
	}

	template<class T>
	bool GTUIteratorConst<T>::operator !=(const GTUIteratorConst& rightSide) const 
	{
		// my helper overload that i used to loop // e.g. while(iter1 != iter2)
		return !((*this) == rightSide);
	}

	template<class T>
	T* GTUIteratorConst<T>::get_traverser() const 
	{
		return traverser;
	}

	template<class T>
	GTUIteratorConst<T>& GTUIteratorConst<T>::operator +(int value)
	{
		traverser += value;

		return (*this);
	}
}