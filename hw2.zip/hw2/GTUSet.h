#ifndef GTUSET_H_
#define GTUSET_H_

#include "GTUContainer.h"

namespace GTUSTL
{
	template<class T>
	class GTUSet : public GTUContainer<T>
	{
		public:
			GTUSet();
			GTUSet(const GTUSet& rightSide);
			GTUSet& operator =(const GTUSet& rightSide);
			bool empty() const;
			int size() const;
			int max_size() const;
			void insert(const T& Object);
			void erase(const T& eraseObject);
			void erase(const GTUIterator<T>& eraseIter);
			void erase(const GTUIterator<T>& start_iterator, const GTUIterator<T>& finish_iterator);
			void clear();
			void printSet() const;
			GTUIterator<T> begin() const;
			GTUIterator<T> end() const;
			static void print_element(T element);
	};
}

#endif